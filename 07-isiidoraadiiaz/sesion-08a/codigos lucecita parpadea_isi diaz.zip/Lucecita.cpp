// importar el archivo header

// importar el archivo header
#include "Lucecita.h"
#include "pico/stdlib.h"

// constructor
Lucecita::Lucecita(int nuevaPatita) {

  // guardar el valor
  Lucecita::patita = nuevaPatita;

  // inicializar patita
  gpio_init(Lucecita::patita);

  // la patita es salida
  gpio_set_dir(Lucecita::patita, GPIO_OUT);

  // partir apagada
  Lucecita::apagar();
}

// metodos
void Lucecita::prender() {

  // hacer true la variable interna
  Lucecita::prendida = true;

  // prender la luz
  gpio_put(Lucecita::patita, true);
}

void Lucecita::apagar() {

  // hacer false la variable interna
  Lucecita::prendida = false;

  // apagar la luz
  gpio_put(Lucecita::patita, false);
}

// hacer parpadear la luz
void Lucecita::parpadear(int frecuencia) {

  Lucecita::prender();
  sleep_ms(frecuencia);

  Lucecita::apagar();
  sleep_ms(frecuencia);
}
