// hay 3 elementos
// lucecita
// perilla
// pulsador

// lucecita necesita R de 220
// perilla necesita nada
// pulsador necesita R de 10k

// entradas
// o sensores
// perilla - posicion rotacional / giro
// pulsador - si o no hay presion

// salidas
// o actuadores
// lucecita

// ya pero y?

// pulsador: prender y apagar todo
// potenciometro: frecuencia de parpadeo

// lucecita: prender y apagarse
// segun lo que diga boton y perilla

// por lo tanto
// boton tiene dos estados
// prendido y apagado

// perilla va a tener
// una posicion que va a ser
// usada por el sistema
// para impactar en parpadeo lucecita




#include <stdio.h>
#include "pico/stdlib.h"

#include "Boton.h"
#include "Perilla.h"
#include "Lucecita.h"

int main() {
  stdio_init_all();

  // crear nuestros elementos
  Boton pulsador(7);
  Perilla parpadeo(26);
  Lucecita luz(6);

  while (true) {

    // leer boton y perilla
    pulsador.leer();
    parpadeo.leer();

    // controlar el tiempo con la perilla
    int tiempo = 200 + parpadeo.posicion / 4;

    // si presionamos el boton se apaga
    if (pulsador.presionado == true) {
      luz.apagar();
    } else {
      // si no, la luz parpadea
      luz.parpadear(tiempo);
    }
  }
}
